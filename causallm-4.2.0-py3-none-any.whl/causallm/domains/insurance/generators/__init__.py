"""
Insurance data generators.
"""

from .insurance_data import InsuranceDataGenerator

__all__ = ['InsuranceDataGenerator']