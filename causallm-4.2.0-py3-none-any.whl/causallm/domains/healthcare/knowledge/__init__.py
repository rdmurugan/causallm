"""
Healthcare domain knowledge.
"""

from .medical_knowledge import MedicalDomainKnowledge

__all__ = ['MedicalDomainKnowledge']